import { useState, useEffect, useCallback } from 'react';
import { ethers } from 'ethers';
import { NetworkManager } from '../utils/network';

interface Web3State {
  provider: ethers.BrowserProvider | null;
  signer: ethers.JsonRpcSigner | null;
  account: string | null;
  chainId: number | null;
  isConnected: boolean;
  isLoading: boolean;
  error: string | null;
}

export const useWeb3 = () => {
  const [web3State, setWeb3State] = useState<Web3State>({
    provider: null,
    signer: null,
    account: null,
    chainId: null,
    isConnected: false,
    isLoading: false,
    error: null,
  });

  const MONAD_TESTNET_CHAIN_ID = parseInt(process.env.NEXT_PUBLIC_CHAIN_ID || '10143');
  
  // 调试链 ID 配置 (开发环境)
  if (process.env.NODE_ENV === 'development') {
    console.log('🔧 Chain ID Configuration:');
    console.log('Environment NEXT_PUBLIC_CHAIN_ID:', process.env.NEXT_PUBLIC_CHAIN_ID);
    console.log('Parsed MONAD_TESTNET_CHAIN_ID:', MONAD_TESTNET_CHAIN_ID);
  }

  const connectWallet = useCallback(async () => {
    console.log('🔗 Starting wallet connection...');
    setWeb3State(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      // 基础检查
      if (typeof window === 'undefined') {
        throw new Error('This application must run in a browser');
      }

      const ethereum = (window as any).ethereum;
      if (!ethereum) {
        throw new Error('MetaMask not found. Please install MetaMask browser extension.');
      }

      console.log('📱 MetaMask detected, requesting connection...');

      // 简单直接的连接请求
      const accounts = await ethereum.request({
        method: 'eth_requestAccounts',
      });

      if (!accounts || accounts.length === 0) {
        throw new Error('No wallet accounts available. Please unlock your wallet.');
      }

      console.log('✅ Account connected:', accounts[0]);

      // 确保在正确的网络上
      const networkCorrect = await NetworkManager.ensureCorrectNetwork();
      if (!networkCorrect) {
        throw new Error('Unable to switch to Monad Testnet. Please manually switch in MetaMask.');
      }

      // 创建provider
      const provider = new ethers.BrowserProvider(ethereum);
      const network = await provider.getNetwork();
      const signer = await provider.getSigner();
      
      console.log('🔗 Network:', network.name, 'Chain ID:', Number(network.chainId));

      setWeb3State({
        provider,
        signer,
        account: accounts[0],
        chainId: Number(network.chainId),
        isConnected: true,
        isLoading: false,
        error: null,
      });

      console.log('🎉 Wallet connection successful!');

    } catch (error: any) {
      console.error('❌ Wallet connection failed:', error);
      
      let errorMessage = 'Failed to connect wallet';
      if (error.code === 4001) {
        errorMessage = 'Connection cancelled by user';
      } else if (error.code === -32002) {
        errorMessage = 'Connection request pending. Please check MetaMask.';
      } else if (error.message) {
        errorMessage = error.message;
      }

      setWeb3State(prev => ({
        ...prev,
        isLoading: false,
        error: errorMessage,
      }));
    }
  }, []);

  const switchToMonadTestnet = useCallback(async () => {
    try {
      const ethereum = (window as any).ethereum;
      
      if (!ethereum) {
        return;
      }
      
      const hexChainId = `0x${MONAD_TESTNET_CHAIN_ID.toString(16)}`;
      
      try {
        await ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: hexChainId }],
        });
      } catch (switchError: any) {
        // Chain not added to MetaMask
        if (switchError.code === 4902) {
          await ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [
              {
                chainId: hexChainId,
                chainName: process.env.NEXT_PUBLIC_NETWORK_NAME || 'Monad Testnet',
                nativeCurrency: {
                  name: 'MON',
                  symbol: 'MON',
                  decimals: 18,
                },
                rpcUrls: ['https://testnet-rpc.monad.xyz'],
                blockExplorerUrls: ['https://testnet-explorer.monad.xyz'],
              },
            ],
          });
        }
      }
    } catch (error) {
      console.warn('Network switch failed:', error);
    }
  }, []);

  const disconnect = useCallback(() => {
    setWeb3State({
      provider: null,
      signer: null,
      account: null,
      chainId: null,
      isConnected: false,
      isLoading: false,
      error: null,
    });
  }, []);

  const clearError = useCallback(() => {
    setWeb3State(prev => ({ ...prev, error: null }));
  }, []);

  // 禁用自动重连，避免 MetaMask 连接错误
  useEffect(() => {
    // 移除自动连接逻辑，只保留事件监听器

    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        disconnect();
      } else {
        setWeb3State(prev => ({
          ...prev,
          account: accounts[0],
        }));
      }
    };

    const handleChainChanged = (chainId: string) => {
      setWeb3State(prev => ({
        ...prev,
        chainId: parseInt(chainId, 16),
      }));
    };

    // 只在用户已连接时添加事件监听器
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      try {
        (window as any).ethereum.on('accountsChanged', handleAccountsChanged);
        (window as any).ethereum.on('chainChanged', handleChainChanged);
      } catch (error) {
        console.warn('Failed to add MetaMask event listeners:', error);
      }

      return () => {
        try {
          if ((window as any).ethereum) {
            (window as any).ethereum.removeListener('accountsChanged', handleAccountsChanged);
            (window as any).ethereum.removeListener('chainChanged', handleChainChanged);
          }
        } catch (error) {
          console.warn('Failed to remove MetaMask event listeners:', error);
        }
      };
    }
  }, [disconnect]);

  return {
    ...web3State,
    connectWallet,
    disconnect,
    clearError,
    switchToMonadTestnet,
    isOnCorrectNetwork: web3State.chainId === MONAD_TESTNET_CHAIN_ID,
  };
};