import React, { useState } from 'react';
import styled from 'styled-components';

const GuideContainer = styled.div`
  background: #fff3cd;
  border: 2px solid #ffc107;
  border-radius: 8px;
  padding: 20px;
  margin: 15px 0;
`;

const GuideTitle = styled.h3`
  color: #856404;
  margin-top: 0;
  display: flex;
  align-items: center;
  gap: 8px;
`;

const StepContainer = styled.div`
  margin: 15px 0;
`;

const StepTitle = styled.h4`
  color: #495057;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 8px;
`;

const ConfigBox = styled.div`
  background: #f8f9fa;
  border: 1px solid #dee2e6;
  border-radius: 4px;
  padding: 10px;
  font-family: 'Courier New', Courier, monospace;
  font-size: 14px;
  margin: 10px 0;
`;

const ConfigRow = styled.div`
  margin: 5px 0;
`;

const CopyButton = styled.button`
  background: #007bff;
  color: white;
  border: none;
  border-radius: 3px;
  padding: 2px 6px;
  font-size: 12px;
  cursor: pointer;
  margin-left: 8px;
  
  &:hover {
    background: #0056b3;
  }
`;

const CollapseButton = styled.button`
  background: none;
  border: none;
  color: #007bff;
  cursor: pointer;
  font-size: 14px;
  text-decoration: underline;
  padding: 0;
  margin-top: 10px;
  
  &:hover {
    color: #0056b3;
  }
`;

const NetworkGuide: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      alert('已复制到剪贴板');
    }).catch(() => {
      alert('复制失败，请手动复制');
    });
  };

  const networkConfig = {
    networkName: 'Monad Testnet',
    rpcUrl: 'https://testnet-rpc.monad.xyz',
    chainId: '10143',
    chainIdHex: '0x279f',
    symbol: 'MON',
    explorerUrl: 'https://testnet-explorer.monad.xyz'
  };

  return (
    <GuideContainer>
      <GuideTitle>
        ⚠️ 无法自动添加网络？手动添加Monad测试网
      </GuideTitle>
      
      <p>如果自动添加网络失败，请按以下步骤手动添加：</p>
      
      <StepContainer>
        <StepTitle>🔧 网络配置信息</StepTitle>
        <ConfigBox>
          <ConfigRow>
            <strong>网络名称:</strong> {networkConfig.networkName}
            <CopyButton onClick={() => copyToClipboard(networkConfig.networkName)}>
              复制
            </CopyButton>
          </ConfigRow>
          <ConfigRow>
            <strong>RPC URL:</strong> {networkConfig.rpcUrl}
            <CopyButton onClick={() => copyToClipboard(networkConfig.rpcUrl)}>
              复制
            </CopyButton>
          </ConfigRow>
          <ConfigRow>
            <strong>链ID:</strong> {networkConfig.chainId}
            <CopyButton onClick={() => copyToClipboard(networkConfig.chainId)}>
              复制
            </CopyButton>
          </ConfigRow>
          <ConfigRow>
            <strong>货币符号:</strong> {networkConfig.symbol}
            <CopyButton onClick={() => copyToClipboard(networkConfig.symbol)}>
              复制
            </CopyButton>
          </ConfigRow>
          <ConfigRow>
            <strong>区块浏览器:</strong> {networkConfig.explorerUrl}
            <CopyButton onClick={() => copyToClipboard(networkConfig.explorerUrl)}>
              复制
            </CopyButton>
          </ConfigRow>
        </ConfigBox>
      </StepContainer>

      <CollapseButton onClick={() => setIsExpanded(!isExpanded)}>
        {isExpanded ? '隐藏详细步骤' : '显示详细添加步骤'}
      </CollapseButton>

      {isExpanded && (
        <>
          <StepContainer>
            <StepTitle>📱 步骤1: 打开MetaMask</StepTitle>
            <p>点击浏览器中的MetaMask插件图标</p>
          </StepContainer>

          <StepContainer>
            <StepTitle>🌐 步骤2: 添加网络</StepTitle>
            <p>1. 点击顶部的网络下拉菜单</p>
            <p>2. 点击"添加网络"或"Add Network"</p>
            <p>3. 点击"手动添加网络"或"Add a network manually"</p>
          </StepContainer>

          <StepContainer>
            <StepTitle>✏️ 步骤3: 填写网络信息</StepTitle>
            <p>将上面配置框中的信息复制并粘贴到对应字段：</p>
            <p>• 网络名称: Monad Testnet</p>
            <p>• 新RPC URL: https://testnet-rpc.monad.xyz</p>
            <p>• 链ID: 10143</p>
            <p>• 货币符号: MON</p>
            <p>• 区块浏览器URL: https://testnet-explorer.monad.xyz</p>
          </StepContainer>

          <StepContainer>
            <StepTitle>✅ 步骤4: 保存并切换</StepTitle>
            <p>1. 点击"保存"按钮</p>
            <p>2. MetaMask会自动切换到新添加的网络</p>
            <p>3. 返回游戏页面，尝试重新连接钱包</p>
          </StepContainer>

          <StepContainer>
            <StepTitle>🎮 步骤5: 获取测试币</StepTitle>
            <p>您需要MON测试币来支付游戏费用。请通过以下方式获取：</p>
            <p>• 访问Monad测试网水龙头</p>
            <p>• 或联系项目方获取测试币</p>
          </StepContainer>
        </>
      )}
    </GuideContainer>
  );
};

export default NetworkGuide;