"use strict";exports.id=58,exports.ids=[58],exports.modules={5058:(e,t,s)=>{let a=s(661).verbose(),r=s(1017),i=s(7147),n=r.join(process.cwd(),"database","minesweeper.db"),o=r.dirname(n);i.existsSync(o)||i.mkdirSync(o,{recursive:!0});let DatabaseMonitor=class DatabaseMonitor{static getSlowQueryThreshold(){return 1e3}static getQueries(){return this.queries||(this.queries=new Map),this.queries}static logQuery(e,t,s=[]){let a=e.trim().split(" ")[0].toUpperCase(),r=this.getQueries(),i=r.get(a)||0;r.set(a,i+1),t>this.getSlowQueryThreshold()&&console.warn(`🐌 Slow query detected (${t}ms):`,{sql:e.substring(0,100)+"...",params:s.length>0?s.slice(0,3):[],duration:t})}static getStats(){let e=this.getQueries();return Object.fromEntries(e)}};let Database=class Database{async connect(){return new Promise((e,t)=>{this.db=new a.Database(n,s=>{s?(console.error("❌ Error opening database:",s.message),t(s)):(this.db.run("PRAGMA foreign_keys = ON;"),this.db.run("PRAGMA journal_mode = WAL;"),this.db.run("PRAGMA synchronous = NORMAL;"),this.db.run("PRAGMA cache_size = 10000;"),this.db.run("PRAGMA temp_store = MEMORY;"),e())})})}async close(){return new Promise((e,t)=>{this.db?this.db.close(s=>{s?t(s):e()}):e()})}async initialize(){try{let e=r.join(process.cwd(),"database","schema-enhanced.sql"),t=i.readFileSync(e,"utf8"),s=t.replace(/--.*$/gm,"").replace(/\/\*[\s\S]*?\*\//g,"").replace(/\s+/g," ").trim();return new Promise((e,t)=>{this.db.exec(s,s=>{s?(console.error("❌ Error executing schema:",s.message),t(s)):e()})})}catch(e){throw console.error("❌ Error initializing database:",e),e}}async run(e,t=[]){let s=Date.now();return new Promise((a,r)=>{this.db.run(e,t,function(i){let n=Date.now()-s;DatabaseMonitor.logQuery(e,n,t),i?(console.error("❌ SQL Error:",i.message),console.error("\uD83D\uDD0D SQL:",e),console.error("\uD83D\uDCDD Params:",t),r(i)):a({id:this.lastID,changes:this.changes})})})}async get(e,t=[]){let s=Date.now();return new Promise((a,r)=>{this.db.get(e,t,(i,n)=>{let o=Date.now()-s;DatabaseMonitor.logQuery(e,o,t),i?(console.error("❌ SQL Error:",i.message),console.error("\uD83D\uDD0D SQL:",e),console.error("\uD83D\uDCDD Params:",t),r(i)):a(n)})})}async all(e,t=[]){let s=Date.now();return new Promise((a,r)=>{this.db.all(e,t,(i,n)=>{let o=Date.now()-s;DatabaseMonitor.logQuery(e,o,t),i?(console.error("❌ SQL Error:",i.message),console.error("\uD83D\uDD0D SQL:",e),console.error("\uD83D\uDCDD Params:",t),r(i)):a(n)})})}async beginTransaction(){return this.run("BEGIN TRANSACTION")}async commit(){return this.run("COMMIT")}async rollback(){return this.run("ROLLBACK")}async transaction(e){try{await this.beginTransaction();let t=await e(this);return await this.commit(),t}catch(e){throw await this.rollback(),e}}constructor(){this.db=null,this.connectionPool=[],this.maxConnections=10,this.activeConnections=0,this.preparedStatements=new Map}async prepare(e){if(!this.preparedStatements.has(e)){let t=await new Promise((t,s)=>{this.db.prepare(e,(e,a)=>{e?s(e):t(a)})});this.preparedStatements.set(e,t)}return this.preparedStatements.get(e)}async executePrepared(e,t=[]){let s=await this.prepare(e);return new Promise((e,a)=>{s.run(t,function(t){t?a(t):e({id:this.lastID,changes:this.changes})})})}async batchInsert(e,t,s){if(0===s.length)return;let a=s.map(()=>`(${t.map(()=>"?").join(", ")})`).join(", "),r=`INSERT INTO ${e} (${t.join(", ")}) VALUES ${a}`,i=s.flat();return this.run(r,i)}async getStats(){let e=await this.get(`
            SELECT 
                (SELECT COUNT(*) FROM users) as userCount,
                (SELECT COUNT(*) FROM game_sessions) as gameCount,
                (SELECT COUNT(*) FROM achievements) as achievementCount,
                (SELECT COUNT(*) FROM user_achievements) as userAchievementCount
        `);return{...e,queryStats:DatabaseMonitor.getStats()}}async maintenance(){await this.run("ANALYZE"),await this.run("PRAGMA wal_checkpoint(TRUNCATE);"),await this.run("VACUUM")}};let l=null,getDatabase=async()=>{if(!l){l=new Database,await l.connect();let e=await l.all(`
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name NOT LIKE 'sqlite_%'
        `);0===e.length&&await l.initialize()}return l};e.exports={Database,getDatabase,DataValidator:class{static validateWalletAddress(e){return/^0x[a-fA-F0-9]{40}$/.test(e)}static validateGameData(e){for(let t of["gameId","walletAddress","gameWidth","gameHeight","mineCount"])if(!e[t])throw Error(`Missing required field: ${t}`);if(e.gameWidth<1||e.gameHeight<1||e.mineCount<1)throw Error("Invalid game dimensions");if(e.mineCount>=e.gameWidth*e.gameHeight)throw Error("Too many mines for board size");return!0}static validateUserData(e){if(!e.walletAddress||!this.validateWalletAddress(e.walletAddress))throw Error("Invalid wallet address");return!0}},DatabaseMonitor,DatabaseManager:class{static async getInstance(){return this.instance||(this.connectionPromise||(this.connectionPromise=getDatabase()),this.instance=await this.connectionPromise),this.instance}static async close(){this.instance&&(await this.instance.close(),this.instance=null,this.connectionPromise=null)}static async getLeaderboard(e,t=50){let s=await this.getInstance(),a="WHERE gs.is_won = 1",r=[];e&&"All"!==e&&(a+=" AND gs.difficulty = ?",r.push(e));let i=`
            SELECT 
                u.wallet_address as playerAddress,
                MAX(gs.final_score) as bestScore,
                MIN(CASE WHEN gs.is_won = 1 THEN gs.game_duration END) as bestTime,
                COUNT(gs.id) as totalGames,
                COUNT(CASE WHEN gs.is_won = 1 THEN 1 END) as totalWins,
                AVG(gs.final_score) as averageScore
            FROM users u
            LEFT JOIN game_sessions gs ON u.id = gs.user_id
            ${a}
            GROUP BY u.id, u.wallet_address
            HAVING totalWins > 0
            ORDER BY bestScore DESC, bestTime ASC
            LIMIT ?
        `;r.push(t);let n=await s.all(i,r);return n.map((e,t)=>({...e,rank:t+1,averageScore:Math.round(e.averageScore||0),bestTime:e.bestTime||0}))}static async getPlayerRank(e,t){let s=await this.getLeaderboard(t,1e3),a=s.find(t=>t.playerAddress.toLowerCase()===e.toLowerCase());return a?a.rank:-1}static async getGameStats(){let e=await this.getInstance(),t=await e.get(`
            SELECT 
                COUNT(gs.id) as totalGames,
                COUNT(DISTINCT u.id) as totalPlayers,
                AVG(gs.final_score) as averageScore,
                MAX(gs.final_score) as topScore
            FROM game_sessions gs
            JOIN users u ON gs.user_id = u.id
            WHERE gs.is_won = 1
        `);return{totalGames:t.totalGames||0,totalPlayers:t.totalPlayers||0,averageScore:Math.round(t.averageScore||0),topScore:t.topScore||0}}static async getPlayerRecords(e){let t=await this.getInstance(),s=await t.all(`
            SELECT 
                gs.id,
                gs.game_id as gameId,
                gs.wallet_address as playerAddress,
                gs.final_score as score,
                gs.game_duration as timeElapsed,
                gs.game_width as width,
                gs.game_height as height,
                gs.mine_count as mines,
                gs.difficulty,
                gs.created_at as timestamp,
                gs.is_won as verified
            FROM game_sessions gs
            WHERE gs.wallet_address = ?
            ORDER BY gs.created_at DESC
        `,[e]);return s.map(e=>({...e,id:e.id.toString(),timestamp:new Date(e.timestamp).getTime(),verified:!!e.verified}))}static async addGameRecord(e){let t=await this.getInstance(),s=await t.get("SELECT id FROM users WHERE wallet_address = ?",[e.playerAddress]);if(!s){let a=await t.run("INSERT INTO users (wallet_address) VALUES (?)",[e.playerAddress]);s={id:a.id}}let a=await t.run(`
            INSERT INTO game_sessions (
                game_id, user_id, wallet_address, game_width, game_height, 
                mine_count, difficulty, is_won, final_score, game_duration
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,[e.gameId,s.id,e.playerAddress,e.width,e.height,e.mines,e.difficulty,e.verified?1:0,e.score,e.timeElapsed]);return{...e,id:a.id.toString(),timestamp:Date.now()}}}}}};