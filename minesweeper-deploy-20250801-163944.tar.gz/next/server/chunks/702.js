"use strict";exports.id=702,exports.ids=[702],exports.modules={7702:(e,r,n)=>{n.r(r),n.d(r,{default:()=>App});var t=n(997),o=n(7518),s=n.n(o),i=n(6689);let a=s().div.withConfig({componentId:"sc-c2038048-0"})`
  padding: 20px;
  margin: 20px;
  border: 2px solid #ff0000;
  border-radius: 8px;
  background: #ffe6e6;
  text-align: center;
`,c=s().h2.withConfig({componentId:"sc-c2038048-1"})`
  color: #cc0000;
  margin-bottom: 10px;
`,d=s().p.withConfig({componentId:"sc-c2038048-2"})`
  color: #666;
  margin-bottom: 15px;
`,l=s().button.withConfig({componentId:"sc-c2038048-3"})`
  padding: 10px 20px;
  background: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  
  &:hover {
    background: #45a049;
  }
`;let ErrorBoundary=class ErrorBoundary extends i.Component{constructor(e){super(e),this.handleRetry=()=>{this.setState({hasError:!1,error:null})},this.state={hasError:!1,error:null}}static getDerivedStateFromError(e){let r=String(e?.message||e||""),n=String(e?.stack||"");return r.includes("MetaMask")||r.includes("ethereum")||r.includes("Failed to connect")||r.includes("chrome-extension")||n.includes("chrome-extension")?{hasError:!1,error:null}:{hasError:!0,error:e}}componentDidCatch(e,r){let n=String(e?.message||e||""),t=String(e?.stack||"");if(n.includes("MetaMask")||n.includes("ethereum")||n.includes("Failed to connect")||n.includes("chrome-extension")||t.includes("chrome-extension")){console.warn("MetaMask error caught by ErrorBoundary and suppressed:",n),this.setState({hasError:!1,error:null});return}console.error("ErrorBoundary caught an error:",e,r)}render(){return this.state.hasError&&this.state.error?this.state.error.message?.includes("MetaMask")||this.state.error.message?.includes("ethereum")||this.state.error.message?.includes("Failed to connect")?this.props.children:(0,t.jsxs)(a,{children:[t.jsx(c,{children:"Oops! Something went wrong"}),t.jsx(d,{children:"We encountered an unexpected error. Please try refreshing the page."}),t.jsx(l,{onClick:this.handleRetry,children:"Try Again"})]}):this.props.children}};let h=o.createGlobalStyle`
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }

  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #c0c0c0;
  }

  button {
    font-family: inherit;
  }
`;function App({Component:e,pageProps:r}){return(0,t.jsxs)(t.Fragment,{children:[t.jsx(h,{}),t.jsx(ErrorBoundary,{children:t.jsx(e,{...r})})]})}}};