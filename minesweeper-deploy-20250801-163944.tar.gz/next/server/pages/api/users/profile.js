"use strict";(()=>{var e={};e.id=77,e.ids=[77],e.modules={145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},4849:(e,a,s)=>{s.r(a),s.d(a,{config:()=>n,default:()=>d,routeModule:()=>o});var r={};s.r(r),s.d(r,{default:()=>handler});var t=s(1802),i=s(7153),u=s(6249);async function handler(e,a){try{let{getDatabase:r}=s(Object(function(){var e=Error("Cannot find module '../../lib/database'");throw e.code="MODULE_NOT_FOUND",e}())),{walletAddress:t}=e.query;if(!t)return a.status(400).json({error:"Wallet address is required"});let i=await r();if("GET"===e.method){let e=await i.get(`
                SELECT 
                    u.*,
                    COUNT(gs.id) as total_sessions,
                    COUNT(CASE WHEN gs.is_won = 1 THEN 1 END) as actual_wins,
                    AVG(CASE WHEN gs.is_won = 1 THEN gs.game_duration END) as avg_win_time,
                    MAX(gs.final_score) as highest_score,
                    MIN(CASE WHEN gs.is_won = 1 THEN gs.game_duration END) as fastest_win,
                    COUNT(ua.id) as achievement_count_actual,
                    SUM(gs.reward_amount) as total_rewards_actual
                FROM users u
                LEFT JOIN game_sessions gs ON u.id = gs.user_id
                LEFT JOIN user_achievements ua ON u.id = ua.user_id
                WHERE u.wallet_address = ?
                GROUP BY u.id
            `,[t]);if(!e)return a.status(404).json({error:"User not found"});let s=await i.all(`
                SELECT 
                    a.achievement_key,
                    a.name,
                    a.description,
                    a.icon_url,
                    a.tier,
                    a.rarity,
                    ua.earned_at
                FROM user_achievements ua
                JOIN achievements a ON ua.achievement_id = a.id
                WHERE ua.user_id = ?
                ORDER BY ua.earned_at DESC
            `,[e.id]),r=await i.all(`
                SELECT 
                    game_id,
                    difficulty,
                    is_won,
                    final_score,
                    game_duration,
                    reward_amount,
                    played_at
                FROM game_sessions
                WHERE user_id = ?
                ORDER BY played_at DESC
                LIMIT 10
            `,[e.id]);return a.status(200).json({success:!0,profile:{...e,achievements:s,recentGames:r}})}if("PUT"!==e.method)return a.status(405).json({error:"Method not allowed"});{let{username:s,email:r,avatar_url:u}=e.body,d=await i.get("SELECT id FROM users WHERE wallet_address = ?",[t]);if(!d)return a.status(404).json({error:"User not found"});return await i.run(`
                UPDATE users 
                SET username = ?, email = ?, avatar_url = ?, updated_at = CURRENT_TIMESTAMP
                WHERE wallet_address = ?
            `,[s||null,r||null,u||null,t]),await i.run(`
                INSERT INTO system_logs (log_type, user_id, wallet_address, action, message, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `,["user_action",d.id,t,"profile_update","User profile updated",e.headers["x-forwarded-for"]||e.connection.remoteAddress,e.headers["user-agent"]]),a.status(200).json({success:!0,message:"Profile updated successfully"})}}catch(e){return console.error("❌ User profile error:",e),a.status(500).json({error:"Internal server error",details:void 0})}}let d=(0,u.l)(r,"default"),n=(0,u.l)(r,"config"),o=new t.PagesAPIRouteModule({definition:{kind:i.x.PAGES_API,page:"/api/users/profile",pathname:"/api/users/profile",bundlePath:"",filename:""},userland:r})}};var a=require("../../../webpack-api-runtime.js");a.C(e);var __webpack_exec__=e=>a(a.s=e),s=a.X(0,[222],()=>__webpack_exec__(4849));module.exports=s})();