"use strict";(()=>{var e={};e.id=610,e.ids=[610],e.modules={145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6497:(e,t,a)=>{a.r(t),a.d(t,{config:()=>c,default:()=>h,routeModule:()=>d});var i={};a.r(i),a.d(i,{default:()=>handler});var s=a(1802),r=a(7153),n=a(6249);let AchievementChecker=class AchievementChecker{constructor(e){this.db=e}async checkScoreAchievements(e,t){let a=[],{final_score:i}=t;for(let t of[{key:"score_1000",threshold:1e3},{key:"score_5000",threshold:5e3},{key:"score_10000",threshold:1e4}])if(i>=t.threshold){let i=await this.db.get(`
                    SELECT 1 FROM user_achievements ua
                    JOIN achievements a ON ua.achievement_id = a.id
                    WHERE ua.user_id = ? AND a.achievement_key = ?
                `,[e,t.key]);i||a.push(t.key)}return a}async checkSpeedAchievements(e,t){let a=[],{game_duration:i,is_won:s}=t;if(!s)return a;for(let t of[{key:"speed_30s",threshold:30},{key:"speed_15s",threshold:15},{key:"speed_10s",threshold:10}])if(i<=t.threshold){let i=await this.db.get(`
                    SELECT 1 FROM user_achievements ua
                    JOIN achievements a ON ua.achievement_id = a.id
                    WHERE ua.user_id = ? AND a.achievement_key = ?
                `,[e,t.key]);i||a.push(t.key)}return a}async checkWinAchievements(e){let t=[],a=await this.db.get("SELECT total_wins FROM users WHERE id = ?",[e]);if(!a)return t;for(let i of[{key:"first_win",threshold:1},{key:"ten_wins",threshold:10},{key:"hundred_wins",threshold:100},{key:"thousand_wins",threshold:1e3}])if(a.total_wins>=i.threshold){let a=await this.db.get(`
                    SELECT 1 FROM user_achievements ua
                    JOIN achievements a ON ua.achievement_id = a.id
                    WHERE ua.user_id = ? AND a.achievement_key = ?
                `,[e,i.key]);a||t.push(i.key)}return t}async checkStreakAchievements(e){let t=[],a=await this.db.all(`
            SELECT is_won FROM game_sessions 
            WHERE user_id = ? 
            ORDER BY played_at DESC 
            LIMIT 25
        `,[e]),i=0;for(let e of a)if(e.is_won)i++;else break;for(let a of[{key:"streak_3",threshold:3},{key:"streak_10",threshold:10},{key:"streak_25",threshold:25}])if(i>=a.threshold){let i=await this.db.get(`
                    SELECT 1 FROM user_achievements ua
                    JOIN achievements a ON ua.achievement_id = a.id
                    WHERE ua.user_id = ? AND a.achievement_key = ?
                `,[e,a.key]);i||t.push(a.key)}return t}async checkDifficultyAchievements(e,t){let a=[],{difficulty:i,is_won:s}=t;if(!s)return a;let r={easy:"easy_master",medium:"medium_master",hard:"hard_master"}[i];if(!r)return a;let n=await this.db.get(`
            SELECT COUNT(*) as count FROM game_sessions 
            WHERE user_id = ? AND difficulty = ? AND is_won = 1
        `,[e,i]);if(n.count>=50){let t=await this.db.get(`
                SELECT 1 FROM user_achievements ua
                JOIN achievements a ON ua.achievement_id = a.id
                WHERE ua.user_id = ? AND a.achievement_key = ?
            `,[e,r]);t||a.push(r)}return a}async checkSpecialAchievements(e,t){let a=[],{game_duration:i,final_score:s,is_won:r,flags_used:n}=t;if(!r)return a;if(i<=60&&s>=1e3){let t=await this.db.get(`
                SELECT 1 FROM user_achievements ua
                JOIN achievements a ON ua.achievement_id = a.id
                WHERE ua.user_id = ? AND a.achievement_key = 'perfect_game'
            `,[e]);t||a.push("perfect_game")}if(0===n){let t=await this.db.get(`
                SELECT 1 FROM user_achievements ua
                JOIN achievements a ON ua.achievement_id = a.id
                WHERE ua.user_id = ? AND a.achievement_key = 'no_flags'
            `,[e]);t||a.push("no_flags")}return a}async checkTokenAchievements(e){let t=[],a=await this.db.get("SELECT total_rewards_earned FROM users WHERE id = ?",[e]);if(!a)return t;if(a.total_rewards_earned>=1e3){let a=await this.db.get(`
                SELECT 1 FROM user_achievements ua
                JOIN achievements a ON ua.achievement_id = a.id
                WHERE ua.user_id = ? AND a.achievement_key = 'token_collector'
            `,[e]);a||t.push("token_collector")}return t}async checkAllAchievements(e,t,a){let i=[],s=await this.checkScoreAchievements(e,t),r=await this.checkSpeedAchievements(e,t),n=await this.checkWinAchievements(e),h=await this.checkStreakAchievements(e),c=await this.checkDifficultyAchievements(e,t),d=await this.checkSpecialAchievements(e,t),u=await this.checkTokenAchievements(e);for(let t of(i.push(...s,...r,...n,...h,...c,...d,...u),i))await this.awardAchievement(e,t,a);return i}async awardAchievement(e,t,a=null){try{let i=await this.db.get("SELECT id FROM achievements WHERE achievement_key = ?",[t]);if(!i)return console.warn(`⚠️ Achievement not found: ${t}`),!1;return await this.db.run(`
                INSERT INTO user_achievements (user_id, achievement_id, game_session_id)
                VALUES (?, ?, ?)
            `,[e,i.id,a]),!0}catch(e){return console.error(`❌ Error awarding achievement ${t}:`,e),!1}}};async function handler(e,t){if("POST"!==e.method)return t.status(405).json({error:"Method not allowed"});try{let{getDatabase:i}=a(Object(function(){var e=Error("Cannot find module '../../lib/database'");throw e.code="MODULE_NOT_FOUND",e}())),{userId:s,gameSessionId:r}=e.body;if(!s||!r)return t.status(400).json({error:"User ID and game session ID are required"});let n=await i(),h=await n.get(`
            SELECT * FROM game_sessions WHERE id = ? AND user_id = ?
        `,[r,s]);if(!h)return t.status(404).json({error:"Game session not found"});let c=new AchievementChecker(n),d=await c.checkAllAchievements(s,h,r),u=[];for(let e of d){let t=await n.get(`
                SELECT achievement_key, name, description, tier, rarity, reward_amount
                FROM achievements WHERE achievement_key = ?
            `,[e]);t&&u.push(t)}return d.length>0&&await n.run(`
                INSERT INTO system_logs (log_type, user_id, action, message, game_session_id, data)
                VALUES (?, ?, ?, ?, ?, ?)
            `,["achievement",s,"achievements_earned",`Earned ${d.length} achievements`,r,JSON.stringify(d)]),t.status(200).json({success:!0,newAchievements:u,message:`Checked achievements, ${d.length} new achievements unlocked`})}catch(e){return console.error("❌ Achievement check error:",e),t.status(500).json({error:"Internal server error",details:void 0})}}let h=(0,n.l)(i,"default"),c=(0,n.l)(i,"config"),d=new s.PagesAPIRouteModule({definition:{kind:r.x.PAGES_API,page:"/api/achievements/check",pathname:"/api/achievements/check",bundlePath:"",filename:""},userland:i})}};var t=require("../../../webpack-api-runtime.js");t.C(e);var __webpack_exec__=e=>t(t.s=e),a=t.X(0,[222],()=>__webpack_exec__(6497));module.exports=a})();