import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useNetwork } from '../utils/network';

const StatusContainer = styled.div`
  background: #f0f0f0;
  border: 2px inset #c0c0c0;
  padding: 15px;
  margin: 10px 0;
  border-radius: 4px;
`;

const StatusItem = styled.div<{ $status: 'success' | 'warning' | 'error' }>`
  margin: 5px 0;
  padding: 5px;
  border-radius: 3px;
  background: ${props => {
    switch (props.$status) {
      case 'success': return '#d4edda';
      case 'warning': return '#fff3cd';
      case 'error': return '#f8d7da';
      default: return 'transparent';
    }
  }};
  color: ${props => {
    switch (props.$status) {
      case 'success': return '#155724';
      case 'warning': return '#856404';
      case 'error': return '#721c24';
      default: return '#000';
    }
  }};
`;

const ActionButton = styled.button`
  padding: 8px 16px;
  margin: 5px;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  
  &:hover {
    background: #0056b3;
  }
  
  &:disabled {
    background: #6c757d;
    cursor: not-allowed;
  }
`;

const NetworkStatus: React.FC = () => {
  const [isOnCorrectNetwork, setIsOnCorrectNetwork] = useState<boolean | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [currentChainId, setCurrentChainId] = useState<string>('');
  const { isOnMonadTestnet, switchToMonadTestnet, networkInfo } = useNetwork();

  const checkNetwork = async () => {
    setIsChecking(true);
    try {
      const correct = await isOnMonadTestnet();
      setIsOnCorrectNetwork(correct);
      
      // 获取当前链ID
      if (typeof window !== 'undefined' && (window as any).ethereum) {
        const chainId = await (window as any).ethereum.request({
          method: 'eth_chainId',
        });
        setCurrentChainId(chainId);
      }
    } catch (error) {
      console.error('Failed to check network:', error);
      setIsOnCorrectNetwork(false);
    } finally {
      setIsChecking(false);
    }
  };

  const handleSwitchNetwork = async () => {
    setIsChecking(true);
    try {
      await switchToMonadTestnet();
      await checkNetwork();
    } catch (error) {
      console.error('Failed to switch network:', error);
    } finally {
      setIsChecking(false);
    }
  };

  useEffect(() => {
    checkNetwork();

    // 监听网络变化
    if (typeof window !== 'undefined' && (window as any).ethereum) {
      const handleChainChanged = () => {
        checkNetwork();
      };

      (window as any).ethereum.on('chainChanged', handleChainChanged);
      return () => {
        (window as any).ethereum.removeListener('chainChanged', handleChainChanged);
      };
    }
  }, []);

  return (
    <StatusContainer>
      <h3>🌐 网络状态</h3>
      
      <StatusItem $status="success">
        <strong>目标网络:</strong> {networkInfo.chainName} (Chain ID: {networkInfo.chainId})
      </StatusItem>
      
      <StatusItem $status="success">
        <strong>RPC:</strong> {networkInfo.rpcUrl}
      </StatusItem>
      
      <StatusItem $status="success">
        <strong>浏览器:</strong> {networkInfo.explorerUrl}
      </StatusItem>
      
      {currentChainId && (
        <StatusItem $status={isOnCorrectNetwork ? "success" : "warning"}>
          <strong>当前网络:</strong> {currentChainId} 
          {isOnCorrectNetwork ? ' ✅ 正确' : ' ⚠️ 需要切换'}
        </StatusItem>
      )}
      
      {isOnCorrectNetwork === false && (
        <StatusItem $status="error">
          ❌ 请切换到Monad测试网以使用游戏功能
        </StatusItem>
      )}
      
      <div>
        <ActionButton onClick={checkNetwork} disabled={isChecking}>
          {isChecking ? '检查中...' : '检查网络'}
        </ActionButton>
        
        {isOnCorrectNetwork === false && (
          <ActionButton onClick={handleSwitchNetwork} disabled={isChecking}>
            {isChecking ? '切换中...' : '切换到Monad测试网'}
          </ActionButton>
        )}
      </div>
    </StatusContainer>
  );
};

export default NetworkStatus;